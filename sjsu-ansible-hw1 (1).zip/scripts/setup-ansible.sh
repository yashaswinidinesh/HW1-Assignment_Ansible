#!/usr/bin/env bash
set -euo pipefail
sudo apt update
sudo apt -y install ansible git unzip python3-apt
ansible --version
